CREATE DATABASE company_personnel;

CREATE TABLE Positions(
	Id INT AUTO_INCREMENT PRIMARY KEY,
	Name VARCHAR(30) NOT NULL,
	Cipher INT NOT NULL UNIQUE,
	LowerBound TINYINT DEFAULT 1,
	UpperBound TINYINT NOT NULL
);

CREATE TABLE Departments(
	Id INT AUTO_INCREMENT PRIMARY KEY,
	Name VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE AllocatedPositions(
	Id INT AUTO_INCREMENT PRIMARY KEY,
	DepartmentId INT NOT NULL,
	PositionId INT NOT NULL,
	Quantity INT NOT NULL,
	CONSTRAINT allocated_positions_departments_fk
	FOREIGN KEY (DepartmentId) REFERENCES Departments(Id),
	CONSTRAINT allocated_positions_positions_fk
	FOREIGN KEY (PositionId) REFERENCES Positions(Id),
	CONSTRAINT department_position_uq
	UNIQUE CLUSTERED(DepartmentId, PositionId)
)

CREATE TABLE Employees(
	Id INT AUTO_INCREMENT PRIMARY KEY,
	FullName VARCHAR(100) NOT NULL UNIQUE,
	Age TINYINT,
	Gender ENUM('Male', 'Female'),
	MaritalStatus ENUM('Married', 'Not married', 'Divorced', 'Engaged')
)

CREATE TABLE EmployeesHistory(
	Id INT AUTO_INCREMENT PRIMARY KEY,
	EmployeeId INT NOT NULL,
	DepartmentId INT NOT NULL,
	PositionId INT NOT NULL,
	Rank TINYINT,
	StartDate DATE NOT NULL,
	EndDate DATE,
	CONSTRAINT employees_history_employees_fk
	FOREIGN KEY (EmployeeId) REFERENCES Employees(Id),
	CONSTRAINT employees_history_departments_fk
	FOREIGN KEY (DepartmentId) REFERENCES Departments(Id),
	CONSTRAINT employees_history_positions_fk
	FOREIGN KEY (PositionId) REFERENCES Positions(Id)
)

SELECT P.Name AS Position, P.LowerBound, P.UpperBound, AP.Quantity
FROM allocatedpositions as AP
JOIN positions as P ON P.Id = AP.PositionId
JOIN departments as D ON AP.DepartmentId = D.Id AND D.Name = '$name'

SELECT D.Name as Department, E.FullName as Employee, E.Age as Age FROM EmployeesHistory as EH
JOIN Employees AS E ON EH.EmployeeId = E.Id AND E.Age >= 55 AND E.Gender = 'Female'
JOIN Departments AS D ON EH.DepartmentId = D.Id
WHERE (EH.EndDate IS NOT NULL AND '$date' BETWEEN EH.StartDate AND EH.EndDate) OR (DATEDIFF('$date', EH.StartDate) >= 0 AND EH.EndDate IS NULL)
ORDER BY D.Name

SELECT E.FullName FROM EmployeesHistory as EH
JOIN Employees as E ON E.Id = EH.EmployeeId AND E.Age <= 20
WHERE EH.PositionId = 1 AND EH.EndDate IS NULL