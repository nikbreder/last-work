$(document).ready(function(){
    names = $('#data').data('names');

    ticks = []
    data = []
    i = 0;
    for (name of Object.keys(names)){
        ticks.push([i, name]);
        data.push([i, names[name]])
        i += 2;
    }

    $.plot($("#placeholder"), [ data ] , { yaxis: { min: 14, max: 20 }, xaxis: { ticks: ticks }, series: { bars: {show: true }}});
})