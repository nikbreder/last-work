<?php 
    require('connect.php');

    $date = $_GET['date'];
    $query = "SELECT D.Name as Department, E.FullName as Employee, E.Age as Age FROM EmployeesHistory as EH
    JOIN Employees AS E ON EH.EmployeeId = E.Id AND E.Age >= 55 AND E.Gender = 'Female'
    JOIN Departments AS D ON EH.DepartmentId = D.Id
    WHERE (EH.EndDate IS NOT NULL AND '$date' BETWEEN EH.StartDate AND EH.EndDate) OR (DATEDIFF('$date', EH.StartDate) >= 0 AND EH.EndDate IS NULL)
    ORDER BY D.Name";

    $result = mysqli_query($connection, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>
<body>
    <table class="table">
        <thead>
            <tr>
                <?php while($field = mysqli_fetch_field($result)) : ?>
                <th><?= $field->name ?></th>
                <?php endwhile; ?>
            </tr>
        </thead>
        <tbody>
            <?php while($row = mysqli_fetch_array($result)) : ?>
            <tr>
                <?php foreach($row as $key=>$val) : ?>
                <?php if (!is_numeric($key)) : ?>
                <td><?= $row[$key] ?></td>
                <?php endif; ?>
                <?php endforeach; ?>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>