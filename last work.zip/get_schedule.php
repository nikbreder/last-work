<?php 
    require('connect.php');

    $name = $_GET['department'];
    $query = "SELECT P.Name AS Position, P.LowerBound, P.UpperBound, AP.Quantity
    FROM allocatedpositions as AP
    JOIN positions as P ON P.Id = AP.PositionId
    JOIN departments as D ON AP.DepartmentId = D.Id AND D.Name = '$name'";

    $result = mysqli_query($connection, $query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>
<body>
    <table class="table">
        <thead>
            <tr>
                <?php while($field = mysqli_fetch_field($result)) : ?>
                <th><?= $field->name ?></th>
                <?php endwhile; ?>
            </tr>
        </thead>
        <tbody>
            <?php while($row = mysqli_fetch_array($result)) : ?>
            <tr>
                <?php foreach($row as $key=>$val) : ?>
                <?php if (!is_numeric($key)) : ?>
                <td><?= $row[$key] ?></td>
                <?php endif; ?>
                <?php endforeach; ?>
            </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>