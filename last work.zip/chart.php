<?php
    require('connect.php');

    $pos_id = $_GET['position'];
    $query = "SELECT E.FullName, E.Age FROM EmployeesHistory as EH
    JOIN Employees as E ON E.Id = EH.EmployeeId AND E.Age <= 20
    WHERE EH.PositionId = $pos_id AND EH.EndDate IS NULL";

    $result = mysqli_query($connection, $query);

    $rows = [];
    while ($row = mysqli_fetch_array($result)){
        $rows[$row['FullName']] = $row['Age'];
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>
<body>
    <div id="data" data-names='<?= json_encode($rows) ?>'></div>
    <div id="placeholder" class='container' style='width: 1000px; height:600px;'>

    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="vendor\almasaeed2010\adminlte\bower_components\Flot\jquery.flot.js"></script>
    <script src="script.js"></script>
</body>
</html>