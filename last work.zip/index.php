<?php
    require('connect.php');

    $deps_query = "SELECT * FROM departments";
    $deps_result = mysqli_query($connection, $deps_query);

    $pos_query = "SELECT * FROM positions";
    $pos_result = mysqli_query($connection, $pos_query);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <h3>Штатное расписание подразделения</h3>
        <form action="/get_schedule.php" id='schedule-form' method='GET'>
            <select name="department" id="department" placeholder='Выберите подразделение' class='form-input'>
                <?php while($row = mysqli_fetch_array($deps_result)) : ?>
                <option value="<?= $row['Name'] ?>"><?= $row['Name'] ?></option>
                <?php endwhile; ?>
            </select>
            <button type="submit" class='btn btn-info'>Запрос</button>
        </form>
    </div>
    <div class="container">
        <h3>Женщины, достигшие пенсионного возраста</h3>
        <form action="/get_female_pensioners.php" method='GET'>
            <input type="date" name="date" id="date" class='form-input'>
            <button type="submit" class="btn btn-info">Запрос</button>
        </form>
    </div>
    <div class="container">
        <h3>Диаграмма</h3>
        <form action="/chart.php" method='GET'>
            <select name="position" id="position" placeholder='Выберите подразделение' class='form-input'>
                <?php while($row = mysqli_fetch_array($pos_result)) : ?>
                <option value="<?= $row['Id'] ?>"><?= $row['Name'] ?></option>
                <?php endwhile; ?>
            </select>
            <button type="submit" class='btn btn-info'>Запрос</button>
        </form>
    </div>


    <script src="script.js"></script>
</body>
</html>